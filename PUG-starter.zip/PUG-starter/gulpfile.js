const gulp = require('gulp');
const pug = require('gulp-pug');
const htmlhint_inline = require('gulp-htmlhint-inline');

gulp.task('pug-compile', () => {
	return gulp.src(['app/pug/**/*.pug', '!app/pug/includes/**/*.pug'])
		.pipe(pug({
			pretty: true
		}))
		.pipe(gulp.dest('app/html'));
});

gulp.task('htmlhint', function () {
	var options = {
		htmlhintrc: './.htmlhintrc',
		ignores: {
			'<?php': '?>'
		},
		patterns: [{
			match: /hoge/g,
			replacement: 'fuga'
		}]
	};

	gulp.src('app/html/*.phtml')
		.pipe(htmlhint_inline(options))
		.pipe(htmlhint_inline.reporter())
		.pipe(htmlhint_inline.reporter('fail'));
});

gulp.task('watch', () => {
	gulp.watch('app/pug/**/*.pug', gulp.series('pug-compile'))
});